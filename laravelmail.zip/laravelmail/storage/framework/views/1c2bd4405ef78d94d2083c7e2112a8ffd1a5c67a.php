<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"> <h1> Welcome Admin </h1> </div>
                        
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="form-group"> 
                    <label for="Subject">Subject </label>  
                    <textarea type="text" class="form-control <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="text" value="<?php echo e(old('text')); ?>" required autocomplete="text">
                    </textarea>
                    </div>

                     <div class="form-group">
                     <label for="emailAttachments">Attachment(s) </label>
                     <input type="file" name="emailAttachments[]" multiple="multiple" id="emailAttachments">
                     </div>

                     <div class="form-group">
                     <button type="submit" class="btn btn-primary">Send Mail</button>
                     </div>      
                    

                  
                        

                  
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelmail\resources\views/home.blade.php ENDPATH**/ ?>